CONFIG = {
    "sheet_id": "1hKMwlnN3GAE4dxVGvq2WHT2-Om9SJ3P91L8cxioAeoo",
    "sheet_tab_name": "RFQ TEST SHEET",
    "credentials_file": "service_account.json",
    "gmail_query": "from:prakash.ventil1@gmail.com newer_than:5d",
    "mark_read_after_processing": False
}
